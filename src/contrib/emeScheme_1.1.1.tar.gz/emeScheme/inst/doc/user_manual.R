## -----------------------------------------------------------------------------
## install the devtools package if not installed yet
## install.packages("devtools")

## as the packages are not yet on CRAN, you have to install the package dmdScheme from github first

# devtools::install_github("Exp-Micro-Ecol-Hub/dmdScheme", ref = "master", build_opts = c("--no-resave-data"))

## to install the newest version emeScheme from github including the vignettes, run:

# devtools::install_github("Exp-Micro-Ecol-Hub/emeScheme", build_opts = NULL)

## than load the package
library(emeScheme)

## ----eval = FALSE, echo = TRUE------------------------------------------------
#  cache(createPermanent = TRUE)

## ----eval=FALSE---------------------------------------------------------------
#  open_new_spreadsheet()

## ----eval=FALSE---------------------------------------------------------------
#  open_new_spreadsheet(keepData = TRUE)

## -----------------------------------------------------------------------------
make_example()

## ----eval = FALSE-------------------------------------------------------------
#  make_example("basic")

## ----eval = FALSE-------------------------------------------------------------
#  report("thenameofyourmetadataspreadsheet.xlsx", path = "the/path/to/your/datafiles", report = "html")

## ----eval=FALSE---------------------------------------------------------------
#  write_xml( read_excel("thenameofyourmetadataspreadsheet.xlsx", file = "thenameofyourmetadataspreadsheet.xlm")

## ----eval=FALSE---------------------------------------------------------------
#  saveRDS( x = read_excel("thenameofyourmetadataspreadsheet.xlsx", file = "thenameofyourmetadataspreadsheet.RDS" )

## ----eval=FALSE---------------------------------------------------------------
#  readRDS( file = "thenameofyourmetadataspreadsheet.RDS" )


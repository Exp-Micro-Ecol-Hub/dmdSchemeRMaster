library(testthat)
library(magrittr)
##
library(emeScheme)
##
test_check("emeScheme")
